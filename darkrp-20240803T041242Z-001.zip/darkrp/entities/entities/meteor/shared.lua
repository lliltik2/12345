ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Meteor"
ENT.Author = "Rickster"
ENT.Contact = "Rickyman35@hotmail.com"
ENT.Spawnable = false
